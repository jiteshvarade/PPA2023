#include<stdio.h>

int main()
{
    int * ptr;

    printf("%d",*ptr);

    return 0;
}


# define NULL (void *)0

int *ptr = NULL;