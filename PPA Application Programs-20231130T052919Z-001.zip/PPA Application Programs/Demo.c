
#include<stdio.h>

int main()
{
    printf("C Programming...\n");

    return 0;
}