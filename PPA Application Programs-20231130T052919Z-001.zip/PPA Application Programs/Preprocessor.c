#include<stdio.h>
#include "Marvellous.h"

# define PI 3.14
# define DOZEN 12

// Entry Point function
int main()
{
    struct Demo obj;

    float Value = 10.0 * 10.0 * PI;
    int Count = 10 * DOZEN;

    printf("Value of No : %d\n",No);
    printf("Area is : %f\n",Value);
    printf("Count is : %d\n",Count);

    return 0;
}

// gcc Preprocessor.c -o Myexe -save-temps