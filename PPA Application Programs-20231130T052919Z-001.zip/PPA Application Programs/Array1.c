#include<stdio.h>

int main()
{
    int No1 = 10;
    int No2 = 20;
    int No3 = 30;
    int No4 = 40;
    int No5 = 50;

    int Arr[5] = {10,20,30,40,50};

    printf("%d\n",No4);

    printf("%d\n",Arr[3]);

    printf("Size of array is : %d\n",sizeof(Arr));
    
    return 0;
}