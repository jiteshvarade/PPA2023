class Demo
{
    public void fun()
    {}
    public final void gun()
    {}
}

class Hello extends Demo
{
    public void fun()
    {}
    public void gun()   // Error
    {}  
}

class Final3
{
    public static void main(String arg[])
    {

    }
}