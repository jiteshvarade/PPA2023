#include<stdio.h>

int main()
{
    char Division = 'A';

    int Age = 23;

    float Marks = 67.89;

    double Value = 90.786548;

    return 0;
}