#include<stdio.h>

int main()
{
    // Loop Counter
    int i = 0;
    int Count = 0;

    printf("Enter number of times you want to display JAY GANESH on screen\n");
    scanf("%d",&Count);

    //    1        2       3
    for( i = 1;  i <= Count;  i++)
    {
        printf("Jay Ganesh...\n");  // 4
    }

    return 0;
}