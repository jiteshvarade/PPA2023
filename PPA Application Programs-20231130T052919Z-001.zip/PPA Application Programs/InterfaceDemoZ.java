interface Demo
{
    void fun();
}

class Hello
{
    void gun()
    {}
}

class Marvellous implements Demo extends Hello
{
    public void fun()
    {}
}